Wine Shop Manager PWA

This is an installable web app (PWA) for iPhone and Android.

IMPORTANT:
- It currently stores data locally in the browser/device.
- For iPhone installation: open index.html from a web-hosted copy in Safari, tap Share, then Add to Home Screen.
- For Android: open the hosted app in Chrome and choose Install app / Add to Home screen.
- A local file opened directly from Files may not support service-worker installation. Hosting is required for the full PWA install experience.

The app includes the prototype features built so far.
